<template>
  <div>
    <h2>구매할 물건들</h2>
    <ul>
      <li v-for="(item, index) in filteredItems" v-bind:key="index">
        {{item.name}}
        <button v-on:click="buyItem(item)">구매</button>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["shopping-items"],
  methods: {
    buyItem: function(item) {
      item.buy = true;
    }
  },
  computed: {
    filteredItems() {
      return this.shoppingItems.filter(item => !item.buy);
    }
  }
};
</script>

<style scoped>
li {
  height: 30px;
}
li button {
  float: right;
  margin-bottom: 5px;
}
</style>
