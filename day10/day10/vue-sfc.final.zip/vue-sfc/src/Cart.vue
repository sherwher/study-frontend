<template>
  <div>
    <cart-header></cart-header>
    <div v-show="showAll">
      <h2>전체 목록</h2>
      <ul>
        <li v-for="(item, index) in items" v-bind:key="index">{{ item.name }}</li>
      </ul>
    </div>
    <input type="checkbox" v-model="showAll">전체목록 보기
    <shop-list v-bind:shopping-items="items"></shop-list>
    <cart-input v-on:add-item="addItem"></cart-input>
    <bought-list v-on:remove-item="removeItem" v-bind:bought-items="items"></bought-list>
    <cart-footer></cart-footer>
  </div>
</template>

<script>
import CartHeader from "./components/CartHeader.vue";
import CartFooter from "./components/CartFooter.vue";
import ShopList from "./components/ShopList.vue";
import BoughtList from "./components/BoughtList.vue";
import CartInput from "./components/CartInput.vue";

export default {
  data: () => {
    return {
      showAll: true,
      items: [
        { name: "무", buy: false },
        { name: "배추", buy: false },
        { name: "쪽파", buy: false },
        { name: "고춧가루", buy: false }
      ]
    };
  },
  components: {
    "cart-header": CartHeader,
    "cart-footer": CartFooter,
    "shop-list": ShopList,
    "bought-list": BoughtList,
    "cart-input": CartInput
  },
  methods: {
    addItem: function(newItem) {
      console.log("item from child:", newItem);
      this.items.push({
        name: newItem,
        buy: false
      });
    },
    removeItem: function(item) {
      var index = this.items.indexOf(item);
      if (index > -1) {
        this.items.splice(index, 1);
      }
    }
  }
};
</script>

<style>
</style>
