<template>
    <p>&copy; Bit Academy</p>
</template>

<script>
export default {

}
</script>

<style>

</style>
