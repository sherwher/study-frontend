<template>
    <h1>{{ title }}</h1>
</template>

<script>
export default {
data: function() {
        return {
            title: "Vue Cart"
        }
    }
}
</script>

<style>

</style>
