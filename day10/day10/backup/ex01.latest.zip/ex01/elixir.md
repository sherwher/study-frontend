Bit Lounge 건강음료 HTML Page
=============================

Page 정보(HEAD)
---------------
TITLE : Bit Lounge 건강음료
Content-Type: text/html; charset=UTF-8

Page 내용(BODY)
---------------

큰 제목 : 건강 음료

작은 제목 1: Green Tea Cooler
음료 이미지 : green.jpg"
문단 : 
  Chock full of vitamins and minerals, this elixir combines the healthful benefits of green tea with a twist of chamomile blossoms and ginger root.
    
작은 제목 2: Raspberry Ice Concentration
음료 이미지 : lightblue.jpg
문단 :
  Combining raspberry juice with lemon grass, citrus peel and rosehips, this icy drink will make your mind feel clear and crisp.

작은 제목 3: Blueberry Bliss Elixir
음료 이미지 : blue.jpg"
문단 : 
  Blueberries and cherry essence mixed into a base of elderflower herb tea will put you in a relaxed state of bliss in no time.

작은 제목 4: Cranberry Antioxidant Blast
음료 이미지 : red.jpg"
문단 : 
  Wake up to the flavors of cranberry and hibiscus in this vitamin C rich elixir.

문단 :
  [링크:메인 페이지]메인으로 돌아가기[/링크]