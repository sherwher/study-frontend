const express = require('express');
const http = require('http');

const bodyParser = require('body-parser');

const app = express();
app.set('port', process.env.PORT || 3000);
app.use(express.static(__dirname + "/public"));
app.use(bodyParser.urlencoded( { extended: false }));
app.set("view engine", "ejs");
app.set("views", __dirname + "/views");

http.createServer(app).listen(app.get('port'), () => {
    console.log("Express Server is listening on port " + app.get('port'));
});