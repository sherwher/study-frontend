Bit Lounge HTML Page
====================

Page 정보(HEAD)
---------------
TITLE : Bit Lounge
Content-Type: text/html; charset=UTF-8

Page 내용(BODY)
---------------

큰 제목 : Welcome to the Lounge
이미지 : drinks.gif 를 표시

문단 :
	라운지에서 시원한 [링크:elixir]건강 음료[/링크], 동료들과의 대화로 하루 스트레스를 확 날려 버리세요. 편안한 음악도 감상하세요. 무선인터넷에도 언제든지 접속 가능합니다.   

작은 제목 : 오시는 길

문단 :
	3층에서 바로 찾을 수 있어요.
</body>
</html>